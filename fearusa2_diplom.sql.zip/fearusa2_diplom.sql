-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 17 2019 г., 09:04
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fearusa2_diplom`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Brigada`
--
-- Создание: Июл 05 2019 г., 22:00
--

DROP TABLE IF EXISTS `Brigada`;
CREATE TABLE `Brigada` (
  `idBrigada` int(11) NOT NULL,
  `brigadirName` varchar(300) DEFAULT NULL,
  `timeWorking` time NOT NULL,
  `vehicleNumber` varchar(45) DEFAULT NULL,
  `reliabilityLevel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Operator`
--
-- Создание: Июл 05 2019 г., 22:00
--

DROP TABLE IF EXISTS `Operator`;
CREATE TABLE `Operator` (
  `idOperator` int(11) NOT NULL,
  `nameOperator` varchar(300) DEFAULT NULL,
  `statusOperator` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Order`
--
-- Создание: Июл 16 2019 г., 20:13
--

DROP TABLE IF EXISTS `Order`;
CREATE TABLE `Order` (
  `idOrder` int(11) NOT NULL COMMENT 'Номер заказа',
  `dateReceipt` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата поступления заказа',
  `operatorReceipt` varchar(300) DEFAULT 'Оператор по умолчанию' COMMENT 'Имя оператора, который принял заказ',
  `titleOrder` varchar(500) DEFAULT NULL COMMENT 'Заголовок заказа',
  `descriptionOrder` mediumtext COMMENT 'Полное описание заказа, что надо сделать',
  `typeCleaning` enum('generalnaya','posle_remonta','standartnaya','reguliarnaya') DEFAULT NULL COMMENT 'Тип уборки (более 7 видов), на выбор. ',
  `mudLevel` enum('1','2','3','4','5') DEFAULT NULL COMMENT 'Уроверь загрязнения, по 5-бальной шкале.',
  `nameBrigadir` varchar(150) DEFAULT NULL COMMENT 'Имя бригадира, который руководит бригадой',
  `footageOrder` int(11) DEFAULT NULL COMMENT 'Метраж помещения, по полу, указывается в м2',
  `parogenerator` enum('Нужен','Не нужен') DEFAULT NULL COMMENT 'Нужен ли парогенератор, да или нет. \n',
  `stremyanka` enum('Нужна стремянка','Не нужна стремянка') DEFAULT NULL COMMENT 'Нужна ли стремянка на объекте или нет.',
  `washingVacuumCleaner` enum('Нужен моющий пылесос','Не нужен моющий пылесос') DEFAULT NULL COMMENT 'Нужен ли моющий пылесос для химчистки при проведении уборки или нет.',
  `windowsQuantity` int(11) DEFAULT NULL COMMENT 'Количество окон в помещении, которые надо помыть.',
  `balconyWindows` int(11) DEFAULT NULL COMMENT 'Количество окон на балконе',
  `dryCleaning` tinyint(4) DEFAULT NULL COMMENT 'Нужна ли химчистка, да или нет.',
  `warshingFurniture` tinyint(4) DEFAULT NULL COMMENT 'Нужно ли мыть мебель в помещениях, да или нет. BOOLEAN автоматически базой данных приводится к типу TINYINT',
  `chandelierWash` tinyint(4) DEFAULT NULL COMMENT 'Надо ли мыть люстры и светильники',
  `ceilingWash` tinyint(4) DEFAULT NULL COMMENT 'Надо ли мыть потолки и потолочные конструкции',
  `workersAmount` int(11) DEFAULT NULL COMMENT 'Количество работников, выделяемых на конкретный объект',
  `typePayment` enum('cash','card','raschetniy_schet','online_site') DEFAULT NULL COMMENT 'Тип платежа (наличными, по карте, с использованием расчетного счета, оплата онлайн через сайт).',
  `sumOrder` int(11) DEFAULT NULL COMMENT 'Сумма заказа',
  `dateCleaning` datetime DEFAULT NULL COMMENT 'Дата уборки и время уборки',
  `commentsOrder` varchar(500) DEFAULT NULL COMMENT 'Комментарии дополнительные от клиента к заказу.',
  `discount` int(11) DEFAULT NULL COMMENT 'Личная скидка клиента',
  `ecoChemicals` tinyint(4) DEFAULT NULL COMMENT 'Нужно ли использовать экологичную химию? Если есть маленькие дети или беременные.',
  `User_idUser` int(11) NOT NULL,
  `Status_idStatus` int(11) NOT NULL,
  `Operator_idOperator` int(11) NOT NULL,
  `Brigada_idBrigada` int(11) NOT NULL,
  `Brigada_timeWorking` time NOT NULL,
  `User_idUser1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `PaymentType`
--
-- Создание: Июл 05 2019 г., 22:00
--

DROP TABLE IF EXISTS `PaymentType`;
CREATE TABLE `PaymentType` (
  `idPaymentType` int(11) NOT NULL,
  `PaymentType` enum('cash','card','raschetniy_schet') NOT NULL,
  `Status` tinyint(4) NOT NULL,
  `Order_idOrder` int(11) NOT NULL,
  `Order_User_idUser` int(11) NOT NULL,
  `Order_Status_idStatus` int(11) NOT NULL,
  `Order_Operator_idOperator` int(11) NOT NULL,
  `Order_Brigada_idBrigada` int(11) NOT NULL,
  `Order_Brigada_timeWorking` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Picture`
--
-- Создание: Июл 13 2019 г., 06:49
-- Последнее обновление: Июл 13 2019 г., 18:06
--

DROP TABLE IF EXISTS `Picture`;
CREATE TABLE `Picture` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `alt` varchar(500) NOT NULL,
  `filename` varchar(500) NOT NULL,
  `idTextData` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Picture`
--

INSERT INTO `Picture` (`id`, `title`, `alt`, `filename`, `idTextData`) VALUES
(1, 'bali', 'Изображение Бали', 'bali2.jpg', '1'),
(2, 'Фото услуги 2', 'услуга фото 2', 'bali1.jpg', '1'),
(3, 'Фото 1 генеральной уборки', 'генуборка квартиры', 'generalnaya-image1.jpg', '2'),
(4, 'Фото 2 генеральной уборки', 'генуборка квартиры паром', 'generalnaya-image2.jpg', '2'),
(5, 'Регулярная уборка', 'Фото регулярной уборки', 'regular-image1.jpg', '3'),
(6, 'Регулярная уборка 2', 'Фото регулярной уборки 2', 'regular-image2.jpg', '3'),
(7, 'Мойка окон в СПб', 'Фото 1 мойки окон', 'moika-okon1.jpg', '4'),
(8, 'Мойка окон в СПб 2', 'Фото 2 мойки окон', 'moika-okon2.jpg', '4');

-- --------------------------------------------------------

--
-- Структура таблицы `Status`
--
-- Создание: Июл 05 2019 г., 22:00
--

DROP TABLE IF EXISTS `Status`;
CREATE TABLE `Status` (
  `idStatus` int(11) NOT NULL,
  `status` varchar(300) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `TEXTDATA`
--
-- Создание: Июл 12 2019 г., 19:29
-- Последнее обновление: Июл 13 2019 г., 18:09
--

DROP TABLE IF EXISTS `TEXTDATA`;
CREATE TABLE `TEXTDATA` (
  `idTextData` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `TEXTDATA`
--

INSERT INTO `TEXTDATA` (`idTextData`, `title`, `text`) VALUES
(1, 'ГЕНЕРАЛЬНАЯ УБОРКА', 'Генеральная уборка — несомненно важное событие как для состояния квартиры, так и для психологического здоровья человека, что и отражается в его названии. \r\nГенеральная уборка в доме или квартире – занятие трудоёмкое, но необходимое. Проводить её нужно регулярно, в противном случае жильё быстро приобретёт неопрятный вид и перестанет быть местом, куда приятно возвращаться после работы.\r\nЛюбая большая уборка начинается с подготовки инвентаря. Набор инструментов, необходимых для генеральной уборки, во многом зависит от размера жилья и финансовых возможностей семьи. Многие предметы будут очень полезны при наведении порядка. Так, моющий пылесос ускорит процесс ликвидации грязи с ковров, но без него легко можно обойтись.'),
(2, 'УБОРКА ПОСЛЕ РЕМОНТА В СПБ', 'Ремонт в доме — дело хлопотное и приятное. Ожидание того, что вскоре будет новый интерьер и привезена новая мебель, придает сил.\r\n\r\nОднако, после проведения всех грязных работ, создается другое впечатление. Везде пыль, грязь и мусор, которые еще предстоит убрать. Как отмыть квартиру после ремонта должен знать каждый. Ведь рано или поздно эта участь коснется каждого.\r\n\r\nСмыть строительную пыль после ремонта с поверхности пола, стенок и потолка можно. Только для напольного покрытия следует выбирать химию в зависимости от его типа.\r\n\r\nВо время ремонта невозможно избежать появления загрязнений. Все помещение покрывается пылевым слоем, который потом потребуется убрать.\r\n\r\nПосле отремонтированного помещения, хочется сразу расставить все по местам и уже обживаться. Однако, это не конец. Сначала потребуется убраться. Вычистить пыль можно, если использовать специальные средства и народные способы.'),
(3, 'РЕГУЛЯРНАЯ УБОРКА ПОМЕЩЕНИЙ', 'Чаще всего проводится ежедневная уборка, хотя для жилых помещений лучше говорить о регулярном характере, когда период между процедурами составляет несколько дней, но не больше недели. Перечень работ может иметь постоянный характер или иметь индивидуальные отличия для каждого случая, но основная направленность услуги — поддержание чистоты, удаление пыли и грязи с поверхностей, появляющихся в результате ежедневной деятельности жильцов. Это профилактические работы, имеющие отличия для каждого типа помещения. Не менее тщательно должна проходить уборка служебных помещений — кухни, ванной комнаты, санузла. Учитывая сложные условия эксплуатации, они подвержены загрязнению больше всего, а от чистоты и гигиеничности сантехники, кухонного оборудования и мебели зависит здоровье проживающих.'),
(4, 'МОЙКА ОКОН ПРОФЕССИОНАЛЬНО', 'Окна не только придают эстетический вид и красоту любому зданию, но и являются своего рода связующим звеном внутреннего помещения с окружающим миром. В современных мегаполисах на улицах зачастую царит пыль и грязь, которая не лучшим образом сказывается на состоянии оконных рам и стекол. Если краски мира за окном вашего дома или офиса перестали радовать вас своей яркостью - возможно, пора подумать про мытье окон спб.\r\n\r\nНаши специалисты помогут Вам быстро и недорого решить проблему грязных окон. Мы предлагаем услугу мойка окон в Санкт-Петербурге. Вы можете заказать мытье окон любого размера, любой площади, на любой высоте. Профессиональный подход к работе, накопленный опыт и грамотное применение современных чистящих средств и необходимого инвентаря для мытья гарантирует отличный результат в самые сжатые сроки. Мы осуществляем мытье окон в квартирах, коттеджах и офисах, в том числе расположенные на высоких этажах. Наличие необходимого оборудования, средств безопасности, современных чистящих средств позволяет нам осуществлять мытье любых стекольных поверхностей на должном профессиональном уровне.');

-- --------------------------------------------------------

--
-- Структура таблицы `Textdata_has_picture`
--
-- Создание: Июл 12 2019 г., 19:34
-- Последнее обновление: Июл 13 2019 г., 04:35
--

DROP TABLE IF EXISTS `Textdata_has_picture`;
CREATE TABLE `Textdata_has_picture` (
  `idTextData` int(11) NOT NULL,
  `idPicture` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Textdata_has_picture`
--

INSERT INTO `Textdata_has_picture` (`idTextData`, `idPicture`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--
-- Создание: Июл 05 2019 г., 22:00
-- Последнее обновление: Июл 13 2019 г., 19:36
--

DROP TABLE IF EXISTS `User`;
CREATE TABLE `User` (
  `idUser` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `phone` varchar(33) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `address` varchar(500) NOT NULL,
  `metro` varchar(200) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `role` enum('USER','ADMIN') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `User`
--

INSERT INTO `User` (`idUser`, `name`, `phone`, `email`, `hash`, `address`, `metro`, `discount`, `role`) VALUES
(16, 'Admin', '+7(999)999-99-99', 'admin@admin.com', '$2y$10$m53hJER8S0YyUA2NJM4eN.eKehhlcYUo3Lr7PVkJFfsDIAGs.Xx5S', '', '', NULL, 'ADMIN'),
(20, 'Юрий', '+7(999)999-99-99', 'yuriikimkz2@mail.ru', '$2y$10$z5cgBAJ9DAxOv6H3rGHGgOMzQY5cH0gronbiG6NGRztQExpoZi3I.', 'СПб', 'СПб', 3, 'USER');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Brigada`
--
ALTER TABLE `Brigada`
  ADD PRIMARY KEY (`idBrigada`,`timeWorking`);

--
-- Индексы таблицы `Operator`
--
ALTER TABLE `Operator`
  ADD PRIMARY KEY (`idOperator`);

--
-- Индексы таблицы `Order`
--
ALTER TABLE `Order`
  ADD PRIMARY KEY (`idOrder`,`User_idUser`,`Status_idStatus`,`Operator_idOperator`,`Brigada_idBrigada`,`Brigada_timeWorking`,`User_idUser1`),
  ADD KEY `fk_Order_Status1_idx` (`Status_idStatus`),
  ADD KEY `fk_Order_Operator1_idx` (`Operator_idOperator`),
  ADD KEY `fk_Order_Brigada1_idx` (`Brigada_idBrigada`,`Brigada_timeWorking`),
  ADD KEY `fk_Order_User1_idx` (`User_idUser1`);

--
-- Индексы таблицы `PaymentType`
--
ALTER TABLE `PaymentType`
  ADD PRIMARY KEY (`idPaymentType`,`Order_idOrder`,`Order_User_idUser`,`Order_Status_idStatus`,`Order_Operator_idOperator`,`Order_Brigada_idBrigada`,`Order_Brigada_timeWorking`),
  ADD KEY `fk_PaymentType_Order1_idx` (`Order_idOrder`,`Order_User_idUser`,`Order_Status_idStatus`,`Order_Operator_idOperator`,`Order_Brigada_idBrigada`,`Order_Brigada_timeWorking`);

--
-- Индексы таблицы `Picture`
--
ALTER TABLE `Picture`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `Status`
--
ALTER TABLE `Status`
  ADD PRIMARY KEY (`idStatus`);

--
-- Индексы таблицы `TEXTDATA`
--
ALTER TABLE `TEXTDATA`
  ADD PRIMARY KEY (`idTextData`);

--
-- Индексы таблицы `Textdata_has_picture`
--
ALTER TABLE `Textdata_has_picture`
  ADD PRIMARY KEY (`idTextData`);

--
-- Индексы таблицы `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Brigada`
--
ALTER TABLE `Brigada`
  MODIFY `idBrigada` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Operator`
--
ALTER TABLE `Operator`
  MODIFY `idOperator` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Order`
--
ALTER TABLE `Order`
  MODIFY `idOrder` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Номер заказа';

--
-- AUTO_INCREMENT для таблицы `Picture`
--
ALTER TABLE `Picture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `Status`
--
ALTER TABLE `Status`
  MODIFY `idStatus` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `TEXTDATA`
--
ALTER TABLE `TEXTDATA`
  MODIFY `idTextData` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `User`
--
ALTER TABLE `User`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Order`
--
ALTER TABLE `Order`
  ADD CONSTRAINT `fk_Order_Brigada1` FOREIGN KEY (`Brigada_idBrigada`,`Brigada_timeWorking`) REFERENCES `Brigada` (`idBrigada`, `timeWorking`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_Operator1` FOREIGN KEY (`Operator_idOperator`) REFERENCES `Operator` (`idOperator`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_Status1` FOREIGN KEY (`Status_idStatus`) REFERENCES `Status` (`idStatus`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_User1` FOREIGN KEY (`User_idUser1`) REFERENCES `User` (`idUser`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `PaymentType`
--
ALTER TABLE `PaymentType`
  ADD CONSTRAINT `fk_PaymentType_Order1` FOREIGN KEY (`Order_idOrder`,`Order_User_idUser`,`Order_Status_idStatus`,`Order_Operator_idOperator`,`Order_Brigada_idBrigada`,`Order_Brigada_timeWorking`) REFERENCES `Order` (`idOrder`, `User_idUser`, `Status_idStatus`, `Operator_idOperator`, `Brigada_idBrigada`, `Brigada_timeWorking`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
