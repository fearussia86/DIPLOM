let titleElems = document.querySelectorAll('.article p:first-child');


for (let i = 0; i < titleElems.length; i++) {

  titleElems[i].addEventListener('click', openDescription);

}

function openDescription() {

  //this - в него придет titleElems[i].addEventListener
  console.log(this);

  this.nextElementSibling.classList.toggle("open");
}


let kabinet = document.getElementById('kabinet');
console.log(kabinet);

kabinet.addEventListener("click", modifyDiv);
let div = document.getElementById('hideBlock');
console.log(div);

function modifyDiv() {
     

      div.classList.remove("hide");
    div.classList.add("window");
    
}




let closeButton = document.getElementById('close-form');
console.log(closeButton);




if(closeButton) {
    closeButton.addEventListener("click", closeDiv);
}

function closeDiv() {
     
      
     console.log(div);
   div.classList.add("hide");     
   div.classList.remove("window");
   
}


/*JS КОД ДЛЯ ТАБОВ*/

function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" w3-border-red", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.firstElementChild.className += " w3-border-red";
}

/*
if(windowClose) {
    kabinet.removeEventListener("click", modifyDiv);
     
} 

*/

/*

function closeForm() {
   let div =  document.querySelector('.window'); 
   div.classList.remove("window");
    div.classList.add("hide");
     
     
}

*/

let tabNav = document.querySelectorAll('.tabs-nav-item');
     let tabContent = document.querySelectorAll('.tab'), tabName;
     console.log(tabNav);
     console.log(tabContent);

   let tab = function() {
        let tabNav = document.querySelectorAll('.tabs-nav-item');
        let tabContent = document.querySelectorAll('.tab'), tabName;
        
        tabNav.forEach(
             
             item=>{
                   item.addEventListener('click', selectTabNav)
             }
             
             );
             
     function selectTabNav() {
          tabNav.forEach(
               item => {
                    item.classList.remove('is-active');
               }
               );
     
     this.classList.add('is-active');   
     tabName = this.getAttribute('data-tab-name');
     console.log(tabName);
     selectTabContent(tabName);

               
     }        
     
      function selectTabContent(tabName) {
        tabContent.forEach(item => {
            item.classList.contains(tabName) ? item.classList.add('is-active') : item.classList.remove('is-active');
        })
    }
     
             
        
   }
     
     
 tab();   
 
 
 //Вызов маски шаблонизатора для телефона
 
     
 

