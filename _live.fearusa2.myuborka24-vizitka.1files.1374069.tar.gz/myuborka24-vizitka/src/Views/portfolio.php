<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $title; ?></title>

  <link rel="stylesheet" href="../css/grid.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  
</head>
<body>

<header>
     
     
     
     
     
     <nav>
          
        
          
          <div class="logo"><a href="/" ></a></div>
          
          <div class="phone-company"><a href="tel:+78122322323">88122322323</a></div>
          
          <ul class="our-menu">
               <li><a href="/">ГЛАВНАЯ</a></li>
               <li><a href="../services">УСЛУГИ</a></li>
               <li><a href="../portfolio">ПОРТФОЛИО</a></li>
               <li><a href="../testimonial">ОТЗЫВЫ</a></li>
               <li><a href="../prices">ЦЕНЫ</a></li>
               
               <li><a href="../contacts">КОНТАКТЫ</a></li>
          </ul>
          
    
      <p><a href="#" class="zvonok zvonok-button ">Обратный звонок</a>
    <a href="#" id="kabinet" class="zvonok zvonok-button ">Личный кабинет</a></p>
     
      
       
     
<div class="hide" id="hideBlock">  
<div id="close-form"></div>
     <?php if ($auth):?>
            <ul class="navbar-nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link" href="/account/logout">Выйти</a>
                </li>
            </ul>
        <?php else: ?>
       
            <form method="post" action="/account/auth" class="my-lg-0 formCabinet">
                 
                <div class="mt-40"> 
                <p><input class="input" name="email" class="" type="email" placeholder="e-mail"></p>
                <p><input class="input" name="password" class="" type="password" placeholder="password"></p>
                
                <button class="input" type="submit">Войти</button>
            </form>
            <ul class="">
                <li class="regSubmit">
                    <div class="" ><center><a id="reg"  href="/account/registration">Регистрация</a></center></div>
                </li>
            </ul>
        <?php  endif;?>
   
   </div>
   
 </div>   
          
          
     </nav>
     

     
</header>

<section id="slider">


<div class="utp">
     <div class="text-slider-active"><h1>УТП ДЛЯ СТРАНИЦЫ ПОРТФОЛИО ИЗ 150 СИМВОЛОВ</h1> </div>
     
     <div class="contact-line">
         <form action="">
              
              
              
             
              <input type="text" name="name" id="yourname" placeholder="Введите Ваше имя">
           
              
           
              <input type="tel" name="phone" id="phone" placeholder="Введите Ваш телефон">
           
              
             
              <input type="submit" value="ЗАКАЗАТЬ">
             
         </form>
         
     </div>
     
     <div class="price-list">
       <a href="#" class="get-price">ПОЛУЧИТЬ ПРАЙС ЛИСТ</a>
     </div>
    
</div>     

 
     
     
</section>


<main>




<section id="case-gallery">
     <div><h2 class="text-typing">ЗАГОЛОВОК КЕЙСОВ</h2></div>
     <div class="case-filters">
     <div class="case-filters-item">Сортировка: </div>
     <div class="case-filters-item"><a href="" class="filter-rem">ПОСЛЕ РЕМОНТА</a></div>
     <div class="case-filters-item"><a href="" class="filter-gen">ГЕНЕРАЛЬНАЯ УБОРКА</a></div>
     <div class="case-filters-item"><a href="" class="filter-reg">РЕГУЛЯРНАЯ УБОРКА</a></div>     
          
     </div>
     <div class="case-area">
          
          <div class="case-item"><img src="images/case-item-clean.jpg" alt=""><p>Кейс 1</p></div>
          <div class="case-item"><img src="images/case-item-clean.jpg" alt=""><p>Кейс 2</p></div>
          <div class="case-item"><img src="images/case-item-clean.jpg" alt=""><p>Кейс 3</p></div>
          <div class="case-item"><img src="images/case-item-clean.jpg" alt=""><p>Кейс 1</p></div>
          <div class="case-item"><img src="images/case-item-clean.jpg" alt=""><p>Кейс 2</p></div>
          <div class="case-item"><img src="images/case-item-clean.jpg" alt=""><p>Кейс 3</p></div>
          <div>Кейс 7</div>
          <div>Кейс 8</div>
          <div>Кейс 9</div>
          
          
     </div>
     
     
</section>



<div class="preimuschestva-portfolio">
<h2 class="text-align-center mt-50 mb-30 test2">НАШИ ПРЕИМУЩЕСТВА</h2>
<span class="test3">Компания работает на рынке с 2012 года, дает гарантии качества.</span>
</div>

<div class="adv">
     
     <div class="adv-item"><img src="images/icons/new-icon1.png" alt="">ПРЕИМУЩЕСТВО 1</div>
     <div class="adv-item"><img src="images/icons/new-icon2.png" alt="">ПРЕИМУЩЕСТВО 2</div>
     <div class="adv-item"><img src="images/icons/new-icon3.png" alt="">ПРЕИМУЩЕСТВО 3</div>
     <div class="adv-item"><img src="images/icons/new-icon4.png" alt="">ПРЕИМУЩЕСТВО 4</div>
     <div class="adv-item"><img src="images/icons/new-icon5.png" alt="">ПРЕИМУЩЕСТВО 5</div>
     <div class="adv-item"><img src="images/icons/new-icon6.png" alt="">ПРЕИМУЩЕСТВО 6</div>
     
     
</div>



<h2 class="text-align-center mt-50 mb-30">НАШИ КЛИЕНТЫ</h2>

<section class="clients">
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     <div class="clients-item">
          Клиент №1
     </div>
     

     
</section>



<section class="aktsia">
     
     <div class="zagolovok"><h2 class="text-align-center mt-50 mb-30">ЗАГОЛОВОК АКЦИИ</h2></div>
     
     <div class="aktsia-item">
          
     </div>
     
     <div class="aktsia-form">
          
     </div>
     
     
</section>


<ul class="tabs">
     <li><h2>РАСКРЫВАЮЩИЕ ТАБЫ ЧЕРЕЗ JS</h2></li>
     <li class="tab-item main-tab">
          <h2>Сколько стоят ваши услуги?</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores, quia, voluptas, magnam, officia nostrum fugiat in optio praesentium est incidunt maiores vel ut distinctio tempore quasi minus libero neque id.</p>
     </li>
     <li class="tab-item">
          <h2>Как давно вы работаете на рынке?</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias, quo, error illo odit quidem ea deserunt doloremque exercitationem aperiam quia provident eligendi. Eum suscipit deleniti officia et dicta adipisci autem!</p>
     </li>
     <li class="tab-item main-tab">
          <h2>Как происходит процесс уборки?</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, delectus, nemo, voluptates harum sunt distinctio eveniet commodi ipsam esse neque quibusdam in numquam inventore ipsum tenetur quasi cum sit consequatur!</p>
     </li>
</ul>

     
</main>


<footer>
     
    <div class="footer-block1">
         <h3>Нижнее меню</h3>
         <ul>
             <li><a href="">Пункт меню 1</a></li>
             <li><a href="">Пункт меню 2</a></li>
             <li><a href="">Пункт меню 3</a></li>
             <li><a href="">Пункт меню 4</a></li>
         </ul>
         
    </div>
    <div class="footer-block2">
         <h3>Популярные услуги</h3>
         <ul>
              <li><a href="">Услуга 1</a></li>
              <li><a href="">Услуга 2</a></li>
              <li><a href="">Услуга 3</a></li>
              <li><a href="">Услуга 4</a></li>
         </ul>
         
    </div>
    <div class="footer-block3">
         <h3>Контактная информация</h3>
         <ul>
              <li>Адрес:</li>
              <li>Телефон:</li>
              <li>Время работы:</li>
              <li>Юридическая информация:</li>
         </ul>
         
    </div>
     
</footer>


<!--div class="grid">
     <div class="item1">Блок 1</div>
     <div class="item2">Блок 2</div>
     <div class="item3">Блок 3</div>
     <div class="item4">Блок 4</div>
     <div class="item5">Блок 5</div>
     <div class="item6"></div>
     <div class="item7"></div>
     <div class="item8"></div>
     <div class="item9"></div>
     <div class="item10"></div>
     <div class="item11"></div>
     <div class="item12"></div>
    
</div!-->

<script src="../js/main.js"></script>


</body>
</html>
