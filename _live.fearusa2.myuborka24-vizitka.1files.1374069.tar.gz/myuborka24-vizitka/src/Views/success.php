
<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title>Успешная регистрация</title>
</head>
<body>
     
<p>Регистрация прошла успешно</p>
<p>Пожалуйста, вернитесь на <a href="/">ГЛАВНУЮ СТРАНИЦУ</a></p>   
<div>Либо подождите <p id="timeReload"></p>10 секунд и Вы автоматически вернетесь на главную страницу сайта.</div>
     
 

<script src="js/relocation.js"></script>
     
</body>
</html>

