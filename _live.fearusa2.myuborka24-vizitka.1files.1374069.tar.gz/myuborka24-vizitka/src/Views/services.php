<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $title; ?></title>

  <link rel="stylesheet" href="../css/grid.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  
</head>
<body>

<header>
     
     
     
     
     
     <nav>
          
        
          
          <div class="logo"><a href="/" ></a></div>
          
          <div class="phone-company"><a href="tel:+78122322323">88122322323</a></div>
          
          <ul class="our-menu">
               <li><a href="/">ГЛАВНАЯ</a></li>
               <li><a href="../services">УСЛУГИ</a></li>
               <li><a href="../portfolio">ПОРТФОЛИО</a></li>
               <li><a href="../testimonial">ОТЗЫВЫ</a></li>
               <li><a href="../prices">ЦЕНЫ</a></li>
               
               <li><a href="../contacts">КОНТАКТЫ</a></li>
          </ul>
          
    
      <p><a href="#" class="zvonok zvonok-button ">Обратный звонок</a>
    <a href="#" id="kabinet" class="zvonok zvonok-button ">Личный кабинет</a></p>
     
      
       
     
<div class="hide" id="hideBlock">  
<div id="close-form"></div>
     <?php if ($auth):?>
            <ul class="navbar-nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link" href="/account/logout">Выйти</a>
                </li>
            </ul>
        <?php else: ?>
       
            <form method="post" action="/account/auth" class="my-lg-0 formCabinet">
                 
                <div class="mt-40"> 
                <p><input class="input" name="email" class="" type="email" placeholder="e-mail"></p>
                <p><input class="input" name="password" class="" type="password" placeholder="password"></p>
                
                <button class="input" type="submit">Войти</button>
            </form>
            <ul class="">
                <li class="regSubmit">
                    <div class="" ><center><a id="reg"  href="/account/registration">Регистрация</a></center></div>
                </li>
            </ul>
        <?php  endif;?>
   
   </div>
   
 </div>   
          
          
     </nav>
     

     
</header>

<section id="slider">


<div class="utp">
     <div class="text-slider-active"><h1>УТП ИЗ 75 СИМВОЛОВ УТП ИЗ 75 СИМВОЛОВ УТП ИЗ 75 СИМВОЛОВ УТП ИЗ 75 СИМВОЛОВ</h1> </div>
     
     <div class="contact-line">
         <form action="">
              
              
              
             
              <input type="text" name="name" id="yourname" placeholder="Введите Ваше имя">
           
              
           
              <input type="tel" name="phone" id="phone" placeholder="Введите Ваш телефон">
           
              
             
              <input type="submit" value="ЗАКАЗАТЬ">
             
         </form>
         
     </div>
     
     <div class="price-list">
       <a href="#" class="get-price">ПОЛУЧИТЬ ПРАЙС ЛИСТ</a>
     </div>
    
</div>     

 
     
     
</section>



<main>
     
    <div class="work-section">
         
     <div class="work-stage">ЭТАП 1</div>
     <div class="work-stage">ЭТАП 2</div>
     <div class="work-stage">ЭТАП 3</div>
     <div class="work-stage">ЭТАП 4</div> 
     <div class="work-stage">ЭТАП 5</div> 
     <div class="work-stage">ЭТАП 6</div> 
         
    </div>
    
   <div class="contact-line">
        <h2 class="mt-50 mb-30">ЖЕЛАЕТЕ УЗНАТЬ БОЛЬШЕ О КАЖДОМ ЭТАПЕ РАБОТ? ОСТАВЬТЕ ЗАЯВКУ.</h2>
        
         <form action="">
              
              
              
             
              <input type="text" name="name" id="yourname" placeholder="Введите Ваше имя">
           
              
           
              <input type="tel" name="phone" id="phone" placeholder="Введите Ваш телефон">
           
              
             
              <input type="submit" value="ЗАКАЗАТЬ">
             
         </form>
         
     </div> 
     
     
     
<h2 class="text-align-center mt-50 mb-30">НАШИ УСЛУГИ</h2>  



<div class="uslugi">

  
     
<div class="usluga-item">
     <img src="images/service-generalnaya.jpg" alt="">
<div>
     <p><a href="usluga/generalnaya">Генеральная уборка</a></p>
</div>
</div>

<div class="usluga-item">
     <img src="images/service-remont.jpg" alt="">
<div>
     <p><a href="usluga/posleremonta">Уборка после ремонта</a></p>
</div>     

</div>
<div class="usluga-item"><img src="images/service-regularnaya.jpg" alt="">

<div>
     <p><a href="usluga/reguliarnaya">Регулярная уборка</a></p>
</div> 
</div>
<div class="usluga-item"><img src="images/service-moika-okon.jpg" alt="">
<div>
     <p><a href="usluga/okna">Мойка окон</a></p>
</div> 
</div>
<div class="usluga-item"><img src="images/case-uborka.jpg" alt="">
<div>
     <p>Услуга 2</p>
</div> 
</div>
<div class="usluga-item"><img src="images/case-uborka.jpg" alt="">
<div>
     <p>Услуга 2</p>
</div> 
</div>
     
</div>


<div class="test">
<h2 class="text-align-center mt-50 mb-30 test2">НАШИ ПРЕИМУЩЕСТВА</h2>
<span class="test3">Компания работает на рынке с 2012 года, дает гарантии качества.</span>
</div>

<div class="adv">
     
     <div class="adv-item">ПРЕИМУЩЕСТВО 1</div>
     <div class="adv-item">ПРЕИМУЩЕСТВО 2</div>
     <div class="adv-item">ПРЕИМУЩЕСТВО 3</div>
     <div class="adv-item">ПРЕИМУЩЕСТВО 4</div>
     <div class="adv-item">ПРЕИМУЩЕСТВО 5</div>
     <div class="adv-item">ПРЕИМУЩЕСТВО 6</div>
     
     
</div>


<h2 class="text-align-center mt-50 mb-30">ОБОРУДОВАНИЕ ДЛЯ КЛИНИНГА</h2>
<div class="tehnika">
     
     
          <div class="tehnika-tab1">Наша техника</div>
          <div class="tehnika-tab2">Наш инвентарь</div>
          <div class="tehnika-tab3">Наша химия</div>
     
     
     
     <div class="tehnika-elem1">Техника 1</div>
     <div class="tehnika-elem2">Техника 2</div>
     <div class="tehnika-elem3">Техника 3</div>
     <div class="tehnika-elem4">Техника 4</div>
     
     
     <div class="tehnika-text">
          * Примечание к блоку, текст 150-160 символов.
     </div>
     
</div>



<h2 class="text-align-center mt-50 mb-30">ПОРТФОЛИО</h2>

<section class="portfolio">
     
     <div class="portfolio-item-main">Кейс с описанием 1</div>
     <div class="portfolio-item">Кейс с описанием 2</div>
     <div class="portfolio-item">Кейс с описанием 3</div>
     <div class="portfolio-item">Кейс с описанием 4</div>
     <div class="portfolio-item">Кейс с описанием 5</div>
     <div class="portfolio-item">Кейс с описанием 6</div>
     <div class="portfolio-item">Кейс с описанием 7</div>
     <div class="portfolio-item-last">Кейс с описанием 8</div>
     
     
</section>


<h2 class="text-align-center mt-50 mb-30">НАШИ КЛИЕНТЫ</h2>

<section class="clients">
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     
     <div class="clients-item">
          Клиент №1
     </div>
     

     
</section>


<section class="aktsia">
     
     <div class="zagolovok"><h2 class="text-align-center mt-50 mb-30">ЗАГОЛОВОК АКЦИИ</h2></div>
     
     <div class="aktsia-item">
          
     </div>
     
     <div class="aktsia-form">
          
     </div>
     
     
</section>

</main>





<footer>
     
    <div class="zagolovok-footer"><h2>ЗАГОЛОВОК ФУТЕРА</h2></div>
    <div><a href="articles">СТАТЬИ</a></div>
    <div></div> 
     
</footer>



<!--div class="grid">
     <div class="item1">Блок 1</div>
     <div class="item2">Блок 2</div>
     <div class="item3">Блок 3</div>
     <div class="item4">Блок 4</div>
     <div class="item5">Блок 5</div>
     <div class="item6"></div>
     <div class="item7"></div>
     <div class="item8"></div>
     <div class="item9"></div>
     <div class="item10"></div>
     <div class="item11"></div>
     <div class="item12"></div>
    
</div!-->

<script src="../js/main.js"></script>


</body>
</html>
