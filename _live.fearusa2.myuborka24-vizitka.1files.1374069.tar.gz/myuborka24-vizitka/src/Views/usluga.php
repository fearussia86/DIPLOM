<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $title; ?></title>

  <link rel="stylesheet" href="../css/grid.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  
</head>
<body>

<header>
     
     
     
     
     
     <nav>
          
        
          
          <div class="logo"><a href="/" ></a></div>
          
          <div class="phone-company"><a href="tel:+78122322323">88122322323</a></div>
          
          <ul class="our-menu">
               <li><a href="/">ГЛАВНАЯ</a></li>
               <li><a href="../services">УСЛУГИ</a></li>
               <li><a href="../portfolio">ПОРТФОЛИО</a></li>
               <li><a href="../testimonial">ОТЗЫВЫ</a></li>
               <li><a href="../prices">ЦЕНЫ</a></li>
               
               <li><a href="../contacts">КОНТАКТЫ</a></li>
          </ul>
          
    
      <p><a href="#" class="zvonok zvonok-button ">Обратный звонок</a>
    <a href="#" id="kabinet" class="zvonok zvonok-button ">Личный кабинет</a></p>
     
      
       
     
<div class="hide" id="hideBlock">  
<div id="close-form"></div>
     <?php if ($auth):?>
            <ul class="navbar-nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link" href="/account/logout">Выйти</a>
                </li>
            </ul>
        <?php else: ?>
       
            <form method="post" action="/account/auth" class="my-lg-0 formCabinet">
                 
                <div class="mt-40"> 
                <p><input class="input" name="email" class="" type="email" placeholder="e-mail"></p>
                <p><input class="input" name="password" class="" type="password" placeholder="password"></p>
                
                <button class="input" type="submit">Войти</button>
            </form>
            <ul class="">
                <li class="regSubmit">
                    <div class="" ><center><a id="reg"  href="/account/registration">Регистрация</a></center></div>
                </li>
            </ul>
        <?php  endif;?>
   
   </div>
   
 </div>   
          
          
     </nav>
     

     
</header>





<!--div class="grid">
     <div class="item1">Блок 1</div>
     <div class="item2">Блок 2</div>
     <div class="item3">Блок 3</div>
     <div class="item4">Блок 4</div>
     <div class="item5">Блок 5</div>
     <div class="item6"></div>
     <div class="item7"></div>
     <div class="item8"></div>
     <div class="item9"></div>
     <div class="item10"></div>
     <div class="item11"></div>
     <div class="item12"></div>
    
</div!-->


    <?php include_once $content;?>


<script src="../js/main.js"></script>
<!--script src="../js/relocation.js"></script!-->
</body>
</html>
