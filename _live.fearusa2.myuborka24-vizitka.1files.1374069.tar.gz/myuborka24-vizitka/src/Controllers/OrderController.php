<?php
namespace web\vizitka\Controllers;
use web\vizitka\Core\Controller;
use web\vizitka\Models\UserRepository;
use web\vizitka\Models\OrderRepository;
class OrderController extends Controller
{
   private $userRepository;
    private $orderRepository;
    public function __construct()
    {
        $this->userRepository = new UserRepository();
        $this->orderRepository = new OrderRepository();
       
    }
    //'/account/registration'
    
    
  public function createAction(){
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
            header('Location: /');
        } else
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                session_start();
            // если post запрос, обрабатываем данные
            $post = $_POST;
            $files = $_FILES;
            $params = [
                'title' => $post['title'],
                'description' => $post['description'],
                'yearCreated' => explode("-", $post['yearCreated'])[0],
                'img' => $files['img']['name']
            ];
            if ($this->orderRepository->save($params) === false) {
                $addResult = 'Картина не была добавлена';
            } else {
                $addResult = 'Картина добавлена';
            }
            $data = [
                'title'=>'Добавление картины',
                'addResult' => $addResult,
                'auth' => isset($_SESSION['name'])
            ];
            echo parent::renderPage('clientAccount.php',
                'clientAccount.php', $data);
        }
    }
    
    
    
}