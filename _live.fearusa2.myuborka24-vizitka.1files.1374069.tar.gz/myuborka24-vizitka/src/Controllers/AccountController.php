<?php
namespace web\vizitka\Controllers;
use web\vizitka\Core\Controller;
use web\vizitka\Models\UserRepository;
use web\vizitka\Models\OrderRepository;
class AccountController extends Controller
{
    private $userRepository;
    public function __construct()
    {
        $this->userRepository = new UserRepository();
        $this->orderRepository = new OrderRepository();
       
    }
    //'/account/registration'
    public function registrationAction(){
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
            $data =[
                'title'=>'Регистрация'
            ];
            echo $this->renderPage('registration.php',
                'registration.php', $data);
        } elseif ($_SERVER['REQUEST_METHOD'] == 'POST'){
            $post = $_POST;
            $params = [
                'username' => $post['name'],
                'email' => $post['email'],
                'phone'=>$post['phone'],
                'address'=>$post['address'],
                'metro'=>$post['metro'],
                'discount'=>$post['discount'],
                'role'=>'USER',
                'hash'=>password_hash($post['password'], PASSWORD_DEFAULT)
            ];
            if($this->userRepository->save($params) === false){
                $data =[
                    'title'=>'Регистрация'
                ];
                echo $this->renderPage('registration.php',
                    'template.php', $data);
            } else {
                header('Location: /success');
                
            }
        }
    }
    public function authAction(){
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            $post = $_POST;
            if (!$this->userRepository->isAuth($post)){
                header('Location: /');
            }
            session_start();
            //$_SESSION['idUser']; 
            header('Location: /account');
            
        }
    }
    
    public function indexAction(){
        session_start();
        if(!isset($_SESSION['name'])) header('Location: /');
       // $accountPage = ($_SESSION['role'] == 'ADMIN') ? 'admin_account.php'  : 'user_account.php';
          
          
     
   /*  $clientData = [
            
             'name' => $session['name'],
             'phone' => $session['phone'],
             'email'=> $session['email'],
             'address'=> $session['address'],
             'metro'=> $session['metro'],
             'discount'=> $session['discount']
             
             ]; 
                                                
     */
     
    
     
      $id = $_SESSION['idUser']; 
      
                                                
     $userData = $this->orderRepository->userRegistrated($id);
      
     
     
        $data = [
            'title' => 'Личный кабинет',
            'name' => $_SESSION['name'],
            'userData' => $userData,
            'auth' => isset($_SESSION['name'])
             
        ];
        
      
        //$session = $_SESSION;
       
         
       echo $this->renderPage($accountPage, 'clientAccount.php', $data);
        
    }
    
    


//МЕТОД ОТПРАВКИ ДАННЫХ С ФОРМЫ ЗАКАЗА (ЛИЧНЫЙ КАБИНЕТ НА СЕРВЕР, В БД

 
   
    
    
    
    public function logoutAction(){
        session_start();
        session_destroy();
        $_SESSION = [];
        header('Location: /');
    }
}