<?php
namespace web\vizitka\Controllers;
use web\vizitka\Core\Controller;
use web\vizitka\Models\PictureRepository;
class TestimonialController extends Controller
{
    private $pictureRepository;
    public function __construct()
    {
        $this->pictureRepository = new PictureRepository();
    }
    public function indexAction(){
        session_start();
        $content='main.php';
        $template='testimonial.php';
        $pictures = $this->pictureRepository->getAll();
        $data=[
            'title'=>'Отзывы наших клиентов о качестве услуг клининга',
            'pictures' => $pictures
            
        ];
        //вывели страничку $page
        echo $this->renderPage($content,$template,$data);
    }
}