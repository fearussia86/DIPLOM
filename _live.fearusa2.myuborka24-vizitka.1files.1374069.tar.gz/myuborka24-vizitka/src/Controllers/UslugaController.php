<?php
namespace web\vizitka\Controllers;
use web\vizitka\Core\Controller;
use web\vizitka\Models\PictureRepository;
class UslugaController extends Controller
{
    private $pictureRepository;
    public function __construct()
    {
        $this->pictureRepository = new PictureRepository();
    }
    
    
    public function generalnayaAction(){
        session_start();
        $content='uslugaContent.php';
        $template='usluga.php';
        //$id = 1;
        
        $idTextData = 1;
       
        
        
	$pictures = $this->pictureRepository->getById($idTextData);

	
	$textData = $this->pictureRepository->getData($idTextData);
        
        $data=[
            'title'=>'Генеральная уборка помещений.',
            'pictures' => $pictures,
            'textData' => $textData,
            'idTextData' => $idTextData,
            

         
            
            //'picturetitle' => $picture['title'],
            //'alt' => $picture['alt'],
            //'filename' => $picture['filename'],
            'auth' => isset($_SESSION['name'])
        ];
        //вывели страничку $page
        echo $this->renderPage($content,$template,$data);
    }
    
    
    public function posleremontaAction(){
        session_start();
        $content='uslugaRemont.php';
        $template='usluga.php';
        
        $idTextData = 2;
        $pictures = $this->pictureRepository->getById($idTextData);

        $textData = $this->pictureRepository->getData($idTextData);
       
        $data=[
            'title'=>'Уборка помещений после ремонта.',
            'pictures' => $pictures,
            'textData' => $textData,
            'idTextData' => $idTextData,
            'auth' => isset($_SESSION['name'])
        ];
        //вывели страничку $page
        echo $this->renderPage($content,$template,$data);
    }
    
    
  public function reguliarnayaAction(){
        session_start();
        $content='reguliarnaya.php';
        $template='usluga.php';
        
        $idTextData = 3;
        $pictures = $this->pictureRepository->getById($idTextData);

        $textData = $this->pictureRepository->getData($idTextData);
       
        $data=[
            'title'=>'Регулярная уборка в СПб и ЛО.',
            'pictures' => $pictures,
            'textData' => $textData,
            'idTextData' => $idTextData,
            'auth' => isset($_SESSION['name'])
        ];
        //вывели страничку $page
        echo $this->renderPage($content,$template,$data);
    }   
    
    
    
    public function oknaAction(){
        session_start();
        $content='okna.php';
        $template='usluga.php';
        
        $idTextData = 4;
        $pictures = $this->pictureRepository->getById($idTextData);

        $textData = $this->pictureRepository->getData($idTextData);
       
        $data=[
            'title'=>'Мойка окон, остекления в Санкт-Петербурге.',
            'pictures' => $pictures,
            'textData' => $textData,
            'idTextData' => $idTextData,
            'auth' => isset($_SESSION['name'])
        ];
        //вывели страничку $page
        echo $this->renderPage($content,$template,$data);
    }   
    
    
    
    
}
