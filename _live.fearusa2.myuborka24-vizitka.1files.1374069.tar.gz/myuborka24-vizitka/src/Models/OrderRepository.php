<?php

namespace web\vizitka\Models;
use web\vizitka\Core\Repository;
use web\vizitka\Core\DB;


//require_once __DIR__ . '/../Core/Repository.php';
//require_once __DIR__ . '/../Models/Picture.php';


class OrderRepository// implements Repository
{
    
    private $db;
    
    public function __construct()
    {
         
         $this->db = DB::getDB();
       
    }
    
    
   // public $session = $_SESSION; 
     
     public function userRegistrated($id) {
         
               $sql = 'SELECT * FROM User WHERE idUser=:idUser';
         $params=[
              'idUser'=>$id
              ];
         
          return $this->db->paramsGetOne($sql, $params);
         
    }
    
   
    public function getById(int $id)
    {
        $sql = 'SELECT FROM Order WHERE id=:id';
        $params = ['id'=>$id];
        return $this->db->paramsGetOne($sql, $params);
    }
    
    
    //В функцию save придут данные  переменные $params, (массив), указанный в файле PictureController
    public function save($params) {
         
$sql = 'INSERT INTO Order (dateReceipt, operatorReceipt, titleOrder, descriptionOrder, typeCleaning, mudLevel, footageOrder, parogenerator, stremyanka, washingVacuumCleaner, windowsQuantity, balconyWindows, dryCleaning, warshingFurniture, workersAmount, typePayment, dateCleaning, commentsOrder, discount) VALUES (:dateReceipt, :operatorReceipt, :titleOrder, :descriptionOrder, :typeCleaning, :mudLevel, :footageOrder, :parogenerator, :stremyanka, :washingVacuumCleaner, :windowsQuantity, :balconyWindows, :dryCleaning, :warshingFurniture, :workersAmount, :typePayment, :dateCleaning, :commentsOrder, :discount)';

return $this->db->nonSelectQuery($sql, $params);
         
    }
    
    
    
}