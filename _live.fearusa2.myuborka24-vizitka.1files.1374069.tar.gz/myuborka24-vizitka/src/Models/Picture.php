<?php
namespace web\vizitka\Models;
class Picture
{
    private $id;
    private $title;
    private $alt;
    private $paths = [];
    public function __construct($id, $title, $alt, $paths)
    {
        $this->id = $id;
        $this->title = $title;
        $this->alt = $alt;
        $this->paths = $paths;
    }
    public function getId()
    {
        return $this->id;
    }
    public function getTitle()
    {
        return $this->title;
    }
    public function getAlt()
    {
        return $this->alt;
    }
    public function getPaths()
    {
        return $this->paths;
    }
}