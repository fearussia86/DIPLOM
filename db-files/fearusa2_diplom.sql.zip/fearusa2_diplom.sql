-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 05 2019 г., 00:17
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fearusa2_diplom`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Brigada`
--
-- Создание: Июл 04 2019 г., 21:08
--

DROP TABLE IF EXISTS `Brigada`;
CREATE TABLE `Brigada` (
  `idBrigada` int(11) NOT NULL,
  `brigadirName` varchar(300) DEFAULT NULL,
  `timeWorking` time NOT NULL,
  `vehicleNumber` varchar(45) DEFAULT NULL,
  `reliabilityLevel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Operator`
--
-- Создание: Июл 04 2019 г., 21:08
--

DROP TABLE IF EXISTS `Operator`;
CREATE TABLE `Operator` (
  `idOperator` int(11) NOT NULL,
  `nameOperator` varchar(300) DEFAULT NULL,
  `statusOperator` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Order`
--
-- Создание: Июл 04 2019 г., 21:11
--

DROP TABLE IF EXISTS `Order`;
CREATE TABLE `Order` (
  `idOrder` int(11) NOT NULL COMMENT 'Номер заказа',
  `dateReceipt` datetime DEFAULT NULL COMMENT 'Дата поступления заказа',
  `operatorReceipt` varchar(300) DEFAULT NULL COMMENT 'Имя оператора, который принял заказ',
  `titleOrder` varchar(500) DEFAULT NULL COMMENT 'Заголовок заказа',
  `descriptionOrder` mediumtext COMMENT 'Полное описание заказа, что надо сделать',
  `typeCleaning` enum('generalnaya','posle_remonta','standartnaya','reguliarnaya','posle_potopa','posle_arendy','himchistka','moika_okon','moika_fasadov') DEFAULT NULL COMMENT 'Тип уборки (более 7 видов), на выбор. ',
  `mudLevel` enum('1','2','3','4','5') DEFAULT NULL COMMENT 'Уроверь загрязнения, по 5-бальной шкале.',
  `nameBrigadir` varchar(150) DEFAULT NULL COMMENT 'Имя бригадира, который руководит бригадой',
  `footageOrder` int(11) DEFAULT NULL COMMENT 'Метраж помещения, по полу, указывается в м2',
  `parogenerator` enum('Нужен','Не нужен') DEFAULT NULL COMMENT 'Нужен ли парогенератор, да или нет. \n',
  `stremyanka` enum('Нужна стремянка','Не нужна стремянка') DEFAULT NULL COMMENT 'Нужна ли стремянка на объекте или нет.',
  `washingVacuumCleaner` enum('Нужен моющий пылесос','Не нужен моющий пылесос') DEFAULT NULL COMMENT 'Нужен ли моющий пылесос для химчистки при проведении уборки или нет.',
  `windowsQuantity` int(11) DEFAULT NULL COMMENT 'Количество окон в помещении, которые надо помыть.',
  `balconyWindows` int(11) DEFAULT NULL COMMENT 'Количество окон на балконе',
  `dryCleaning` tinyint(4) DEFAULT NULL COMMENT 'Нужна ли химчистка, да или нет.',
  `warshingFurniture` tinyint(4) DEFAULT NULL COMMENT 'Нужно ли мыть мебель в помещениях, да или нет. BOOLEAN автоматически базой данных приводится к типу TINYINT',
  `chandelierWash` tinyint(4) DEFAULT NULL COMMENT 'Надо ли мыть люстры и светильники',
  `ceilingWash` tinyint(4) DEFAULT NULL COMMENT 'Надо ли мыть потолки и потолочные конструкции',
  `workersAmount` int(11) DEFAULT NULL COMMENT 'Количество работников, выделяемых на конкретный объект',
  `typePayment` enum('cash','card','raschetniy_schet','online_site') DEFAULT NULL COMMENT 'Тип платежа (наличными, по карте, с использованием расчетного счета, оплата онлайн через сайт).',
  `sumOrder` int(11) DEFAULT NULL COMMENT 'Сумма заказа',
  `dateCleaning` datetime DEFAULT NULL COMMENT 'Дата уборки и время уборки',
  `commentsOrder` varchar(500) DEFAULT NULL COMMENT 'Комментарии дополнительные от клиента к заказу.',
  `discount` int(11) DEFAULT NULL COMMENT 'Личная скидка клиента',
  `ecoChemicals` tinyint(4) DEFAULT NULL COMMENT 'Нужно ли использовать экологичную химию? Если есть маленькие дети или беременные.',
  `User_idUser` int(11) NOT NULL,
  `Status_idStatus` int(11) NOT NULL,
  `Operator_idOperator` int(11) NOT NULL,
  `Brigada_idBrigada` int(11) NOT NULL,
  `Brigada_timeWorking` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `PaymentType`
--
-- Создание: Июл 04 2019 г., 21:11
--

DROP TABLE IF EXISTS `PaymentType`;
CREATE TABLE `PaymentType` (
  `idPaymentType` int(11) NOT NULL,
  `PaymentType` enum('cash','card','raschetniy_schet') NOT NULL,
  `Status` tinyint(4) NOT NULL,
  `Order_idOrder` int(11) NOT NULL,
  `Order_User_idUser` int(11) NOT NULL,
  `Order_Status_idStatus` int(11) NOT NULL,
  `Order_Operator_idOperator` int(11) NOT NULL,
  `Order_Brigada_idBrigada` int(11) NOT NULL,
  `Order_Brigada_timeWorking` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Status`
--
-- Создание: Июл 04 2019 г., 21:11
--

DROP TABLE IF EXISTS `Status`;
CREATE TABLE `Status` (
  `idStatus` int(11) NOT NULL,
  `status` varchar(300) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--
-- Создание: Июл 04 2019 г., 21:08
--

DROP TABLE IF EXISTS `User`;
CREATE TABLE `User` (
  `idUser` int(11) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `phone` varchar(33) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `metro` varchar(200) DEFAULT NULL,
  `personal_discrount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Brigada`
--
ALTER TABLE `Brigada`
  ADD PRIMARY KEY (`idBrigada`,`timeWorking`);

--
-- Индексы таблицы `Operator`
--
ALTER TABLE `Operator`
  ADD PRIMARY KEY (`idOperator`);

--
-- Индексы таблицы `Order`
--
ALTER TABLE `Order`
  ADD PRIMARY KEY (`idOrder`,`User_idUser`,`Status_idStatus`,`Operator_idOperator`,`Brigada_idBrigada`,`Brigada_timeWorking`),
  ADD KEY `fk_Order_User_idx` (`User_idUser`),
  ADD KEY `fk_Order_Status1_idx` (`Status_idStatus`),
  ADD KEY `fk_Order_Operator1_idx` (`Operator_idOperator`),
  ADD KEY `fk_Order_Brigada1_idx` (`Brigada_idBrigada`,`Brigada_timeWorking`);

--
-- Индексы таблицы `PaymentType`
--
ALTER TABLE `PaymentType`
  ADD PRIMARY KEY (`idPaymentType`,`Order_idOrder`,`Order_User_idUser`,`Order_Status_idStatus`,`Order_Operator_idOperator`,`Order_Brigada_idBrigada`,`Order_Brigada_timeWorking`),
  ADD KEY `fk_PaymentType_Order1_idx` (`Order_idOrder`,`Order_User_idUser`,`Order_Status_idStatus`,`Order_Operator_idOperator`,`Order_Brigada_idBrigada`,`Order_Brigada_timeWorking`);

--
-- Индексы таблицы `Status`
--
ALTER TABLE `Status`
  ADD PRIMARY KEY (`idStatus`);

--
-- Индексы таблицы `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Brigada`
--
ALTER TABLE `Brigada`
  MODIFY `idBrigada` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Operator`
--
ALTER TABLE `Operator`
  MODIFY `idOperator` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Order`
--
ALTER TABLE `Order`
  MODIFY `idOrder` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Номер заказа';

--
-- AUTO_INCREMENT для таблицы `Status`
--
ALTER TABLE `Status`
  MODIFY `idStatus` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `User`
--
ALTER TABLE `User`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Order`
--
ALTER TABLE `Order`
  ADD CONSTRAINT `fk_Order_Brigada1` FOREIGN KEY (`Brigada_idBrigada`,`Brigada_timeWorking`) REFERENCES `Brigada` (`idBrigada`, `timeWorking`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_Operator1` FOREIGN KEY (`Operator_idOperator`) REFERENCES `Operator` (`idOperator`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_Status1` FOREIGN KEY (`Status_idStatus`) REFERENCES `Status` (`idStatus`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_User` FOREIGN KEY (`User_idUser`) REFERENCES `User` (`idUser`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `PaymentType`
--
ALTER TABLE `PaymentType`
  ADD CONSTRAINT `fk_PaymentType_Order1` FOREIGN KEY (`Order_idOrder`,`Order_User_idUser`,`Order_Status_idStatus`,`Order_Operator_idOperator`,`Order_Brigada_idBrigada`,`Order_Brigada_timeWorking`) REFERENCES `Order` (`idOrder`, `User_idUser`, `Status_idStatus`, `Operator_idOperator`, `Brigada_idBrigada`, `Brigada_timeWorking`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
