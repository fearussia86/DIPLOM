<?php
namespace web\vizitka\Core;
interface Repository
{
    public function getAll(); // получение всех записей
    public function getById(int $idTextData); // получение записи по id

    public function save($data); // добавление новой записи
    public function getData(int $idTextData); //Получение записей из таблицы TEXTDATA
     //Получаем записи путей картинок из таблицы Picture по внешнему ключу, соответстующему id заголовка в другой таблице.
     
     public function userRegistrated($session); //Для получения данных в форму в личном кабинете пользователя для оформления заказа
}