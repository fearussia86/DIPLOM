<?php 
namespace web\vizitka\Models;
use web\vizitka\Core\Repository;
use web\vizitka\Core\DB;


class UserRepository implements Repository 

{
     
     
     private $db;
     
     public function __construct() {
          $this->db=DB::getDB();
     }
     
     
     
     public function getData($idTextData) {
          
     }
     
     public function getAll() {
          
     }
     
     public function getById($id) {
          
     }
     
     
         public function save($params) {
         
$sql = 'INSERT INTO User (email, `name`, hash, phone, address, metro, discount, role) VALUES (:email, :username, :hash, :phone, :address, :metro, :discount, :role)';

return $this->db->nonSelectQuery($sql, $params);
         
    }
    
    
    public function isAuth($post) {
         $sql = 'SELECT * FROM User WHERE email=:email';
         $params=[
              'email'=>$post['email']
              ];
         $result = $this->db->paramsGetOne($sql, $params);
         
         //
         if(!$result) return false;
         
         //Если в таблице найдена запись по емейлу, то проверяем по паролю. 
         if(!password_verify($post['password'], $result['hash'])) {
              return false;
         }
         
         session_start();
         $_SESSION['name'] = $result['name'];
         $_SESSION['role'] = $result['role'];
         return true;
    }
     
     
     
     
}

?>