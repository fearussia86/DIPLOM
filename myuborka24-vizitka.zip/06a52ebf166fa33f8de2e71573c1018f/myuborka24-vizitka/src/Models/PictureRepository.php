<?php
namespace web\vizitka\Models;

use web\vizitka\Core\DB;
use web\vizitka\Core\Repository;
use web\vizitka\Models\Picture;

class PictureRepository implements Repository
{
    private $db;
    public function __construct()
    {
        $this->db = DB::getDB();
    }
    
    
   public function getData(int $idTextData){
         $sql = 'SELECT * FROM TEXTDATA WHERE idTextData=:idTextData';
         
       $params = [
             'idTextData'=>$idTextData,
           
             
             
             ];
        return $this->db->paramsGetAll($sql, $params);
         
    }

    public function getAll()
    {
        // возвращает все картины
        $sql = 'SELECT * FROM Picture';
        return $this->db->getAll($sql);
    }

    public function getById(int $idTextData)
    {
        // получаем картину по id
        $sql = 'SELECT * FROM Picture WHERE idTextData = :idTextData';
        $params = [
             'idTextData'=>$idTextData,
           
             
             
             ];
        return $this->db->paramsGetAll($sql, $params);
        
        
        
    }
    
    

    
    
    
    
    


    public function save($params)
    {
        $sql = 'INSERT INTO Picture 
                (title, alt, filename)
                VALUES (:title, :alt, :filename)';
        return $this->db->nonSelectQuery($sql, $params);
    }

}