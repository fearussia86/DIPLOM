<?php

namespace web\vizitka\Models;

use web\vizitka\Core\DB;
use web\vizitka\Core\Repository;
use web\vizitka\Core\Article;

//require_once __DIR__ . '/../Core/Repository.php';
//require_once __DIR__ . '/../Models/Picture.php';


class OrderRepository implements Repository
{
    
    private $db;
    
    public function __construct()
    {
         
         $this->db = DB::getDB();
       
    }
    
    
    public $session = $_SESSION;
    
    
     public function userRegistrated($session) {
          
          
         
               $sql = 'SELECT * FROM Order WHERE id=:id';
         $params=[
              'id'=>$session['id']
              ];
         $result = $this->db->paramsGetOne($sql, $params);
         
          
         
    }
    
   
    public function getById(int $id)
    {
        $sql = 'SELECT FROM Order WHERE id=:id';
        $params = ['id'=>$id];
        return $this->db-paramsGetOne($sql, $params);
    }
    
    
    //В функцию save придут данные  переменные $params, (массив), указанный в файле PictureController
    public function save($params) {
         
$sql = 'INSERT INTO Article (title, content, date) VALUES (:title, :content, :date)';

return $this->db->nonSelectQuery($sql, $params);
         
    }
    
    
    
}