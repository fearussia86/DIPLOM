<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title><?php echo $title?></title>
</head>
<body>
     
     <div>
          <h1>Блог сайта уборки. Более 300 интересных и полезных статей.</h1>
     </div>
     
</body>
</html>

