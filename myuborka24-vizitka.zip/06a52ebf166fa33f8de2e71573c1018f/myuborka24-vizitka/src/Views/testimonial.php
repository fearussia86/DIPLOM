<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title><?php echo $title?></title>
</head>
<body>
     
     <div>
          <h1>Здесь будут выведены отзывы наших клиентов, текст которых подтянут будет из базы данных.</h1>
     </div>
     
</body>
</html>

