
<section id="slider-general">


<div class="utp">
     
     <div class="text-slider-active white text-center mt-5percents"><h1><?php echo $title;?></h1> </div>
     
     
     
     <div class="contact-line">
         <form action="">
              
              
              
             
              <input type="text" name="name" id="yourname" placeholder="Введите Ваше имя">
           
              
           
              <input type="tel" name="phone" id="phone" placeholder="Введите Ваш телефон">
           
              
             
              <input type="submit" value="ОСТАВИТЬ ЗАЯВКУ">
             
         </form>
         
     </div>
     
     <div class="white text-center utp-text">
          
          Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electroni. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electroni. 
     </div>
     
     <div class="price-list white text-center">
       <a href="#" class="get-price white text-center">ПОЛУЧИТЬ ПРАЙС ЛИСТ</a>
     </div>
    
</div>     

 
     
     
</section>



<main>
     
     <section class="text-area">
          
          
          
     </section>
     
     
<section class="text-area">
     
     <div>
          
          <?php foreach ($textData as $datas): ?>
<!--        заголовок статьи-->
        
       
       
           <h2> <?php  echo $datas['title']; ?> </h2>
       
    
    <?php endforeach; ?>
         
     </div>
     
     <article>
          
          <?php foreach ($textData as $datas): ?>
<!--        заголовок статьи-->
             
             
       
            <?php echo $datas['text']; ?>
       
    
    <?php endforeach; ?>
          
     </article>
     
<div class="double-images">
          
         <div class="article-img">
         
             
        <?php foreach ($pictures as $picture): ?>
<!--        заголовок статьи-->

              
        <img src="../images/<?php echo $picture['filename']; ?>" alt="<?php echo $picture['alt'];?> ">
             
  
    <?php endforeach; ?>
   
      </div>     
     
     
     
</section>     
  
    



     
     
     



<div class="w3-container">
  <h2 class="text-align-center mt-50 mb-30">НАША ТЕХНИКА И ОБОРУДОВАНИЕ</h2>

  <div class="w3-row">
    <a href="javascript:void(0)" onclick="openCity(event, 'London');">
      <div class="w3-third tablink w3-bottombar w3-hover-light-grey w3-padding">Техника</div>
    </a>
    <a href="javascript:void(0)" onclick="openCity(event, 'Paris');">
      <div class="w3-third tablink w3-bottombar w3-hover-light-grey w3-padding">Инвентарь</div>
    </a>
    <a href="javascript:void(0)" onclick="openCity(event, 'Tokyo');">
      <div class="w3-third tablink w3-bottombar w3-hover-light-grey w3-padding">Химия</div>
    </a>
  </div>

  <div id="London" class="w3-container city" style="display:visible">
    <h2>Информация о технике</h2>
    <p>В работе мы используем следующую технику брендов Керхер, Клинфикс, Арьете, Тенант.</p>
    
    <ul>
         <li>Строительные и мощные бытовые пылесосы Керхер.</li>
         <li>Поломоечные машины</li>
         <li>Роторные сетевые машины</li>
         <li>Парогенераторы бытовые Керхер SC3, SC4, SC5</li>
    </ul>
  </div>

  <div id="Paris" class="w3-container city" style="display:none">
    <h2>Информация о химии</h2>
    <p>В работе с различными поверхностями для генеральной уборки, мы используем следующие средства. </p> 
    
    <ul>
         <li>Химия Керхер, для химчистки мягких изделий, мягкой мебели.</li>
         <li>Средства компании ECO LAB, в том числе и экологически чистую линию применяем для ухода за квартирами, коттеджами.</li>
         <li>Химия KiiTo для удаления бытовых загрязнений и чистки поверхностей.</li>
         <li>PRO BRITE для уборки производственных, коммерческих и складских помещений, при проведении генеральных работ.</li>
    </ul>
  </div>

  <div id="Tokyo" class="w3-container city" style="display:none">
    <h2>Информация об инвентаре</h2>
    <p>Для ухода за поверхностями используем тележки Vileda, МОПЫ и телескопы Vileda, телескопические штанги, инвентарь фирмы Unger.</p>
  </div>
</div>








<h2 class="text-align-center mt-50 mb-30">ПОРТФОЛИО</h2>

<section class="portfolio">
     
     <div class="portfolio-item-main"><img src="../images/case-uborka-diplom.jpg" alt="">Помыли 27 окон в КП Земляничная поляна</div>
     <div class="portfolio-item"><img src="../images/case-uborka-diplom2.jpg" alt="">Произвели уборку офиса, 300 м2</div>
     <div class="portfolio-item"><img src="../images/case-uborka-diplom3.jpg" alt="">Регулярная уборка офисов Газпром распределение, 750 м2</div>
     <div class="portfolio-item"><img src="../images/case-uborka-diplom4.jpg" alt="">Уборка квартиры, 108 м2 на ул. Народная 23</div>
     <div class="portfolio-item"><img src="../images/case-uborka-diplom5.jpg" alt="">Уборка после ремонта медицинского центра, 310 м2</div>
     <div class="portfolio-item"><img src="../images/case-uborka-diplom6.jpg" alt="">Уборка стоматологии, 650 м2 на Б. Зеленина</div>
     <div class="portfolio-item"><img src="../images/case-uborka-diplom7.jpg" alt="">Уборка складских помещений Wildberries, Шушары</div>
     <div class="portfolio-item-last"><img src="../images/case-uborka-diplom8.jpg" alt="">Генеральная уборка склада в Шушарах, 3500 м2</div>
     
     
</section>



  <h2 class="text-align-center mt-50 mb-30">СОПУТСТВУЮЩИЕ УСЛУГИ</h2>  

<div class="uslugi">

     
<div class="usluga-item">
     
<div><a href="#">Все услуги клининга</a></p>
</div>
</div>

<div class="usluga-item">
    
<div>
    <a href="#">Регулярная уборка</a>
</div>     

</div>

<div class="usluga-item">

<div>
     <a href="#">Мойка окон</a>
</div> 
</div>
<div class="usluga-item">
<div>
    <a href="#">Мойка фасадов</a>
</div> 
</div>
<div class="usluga-item">
<div>
    <a href="#">Химчистка мягкой мебели</a>
</div> 
</div>
<div class="usluga-item">
<div>
     <a href="#">Уборка коттеджей</a>
</div> 
</div>
     
</div>


<h2 class="text-align-center mt-50 mb-30">НАШИ КЛИЕНТЫ</h2>

<section class="clients">
     
     <div class="clients-item">
          <img src="../images/client1.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client2.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client3.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client4.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client1.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client5.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client5.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client5.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client1.jpg" alt="">
     </div>
     
     <div class="clients-item">
           <img src="../images/client5.jpg" alt="">
     </div>
     

     
</section>


<section class="aktsia">
     
     <div class="zagolovok"><h2 class="text-align-center mt-50 mb-30">ЗАГОЛОВОК АКЦИИ</h2></div>
     
     <div class="aktsia-item">
          <div class="aktsia-text">
               Текст акции, на 250-300 символов.
          </div>
          
     </div>
     
     <div class="aktsia-form">
          <h3>ФОРМА ЗАКАЗА</h3>
          <form action="" id="Form">
               
               <p><input type="text" placeholder="Введите Ваше имя" name="name"></p>
               <p><input type="tel" placeholder="Введите Ваш телефон" name="phone"></p>
               <p><input type="submit" value="ОТПРАВИТЬ"></p>
               
               
          </form>
          
     </div>
     
     
</section>

</main>





<footer>
     
    <div class="footer-block1">
         <h3>Нижнее меню</h3>
         <ul>
             <li><a href="">Пункт меню 1</a></li>
             <li><a href="">Пункт меню 2</a></li>
             <li><a href="">Пункт меню 3</a></li>
             <li><a href="">Пункт меню 4</a></li>
         </ul>
         
    </div>
    <div class="footer-block2">
         <h3>Популярные услуги</h3>
         <ul>
              <li><a href="">Услуга 1</a></li>
              <li><a href="">Услуга 2</a></li>
              <li><a href="">Услуга 3</a></li>
              <li><a href="">Услуга 4</a></li>
         </ul>
         
    </div>
    <div class="footer-block3">
         <h3>Контактная информация</h3>
         <ul>
              <li>Адрес:</li>
              <li>Телефон:</li>
              <li>Время работы:</li>
              <li>Юридическая информация:</li>
         </ul>
         
    </div>
     
</footer>