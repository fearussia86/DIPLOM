<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title><?php echo $title;?></title>
     <link rel="stylesheet" href="../css/style.css">
     
     <link rel="stylesheet" href="../css/bootstrap.css">
     <link rel="stylesheet" href="../css/bootstrap-grid.css">
     <link rel="stylesheet" href="../css/bootstrap-reboot.css">
     <link rel="stylesheet" href="../css/font-awesome.css">
     
     
     <script src="../js/bootstrap.js"></script>
    <script src="../js/bootstrap.bundle.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

   
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    
     
     
</head>
<body>
     


<div class="offset-4 col-4">
    <h3>Заполните форму регистрации</h3>
    <form method="post" action="/account/registration" class="form-registration">
        <div class="form-group">
            <label for="name">Имя</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="введите имя" required>
        </div>
        
        <div class="form-group">
            <label for="phone">Телефон</label>
            <input type="text" class="form-control" id="phone" name="phone" required>
        </div>
        
        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="введите E-mail" required>
        </div>
        <div class="form-group">
            <label for="password">Пароль</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="введите пароль" required>
        </div>
        
         <div class="form-group">
            <label for="address">Адрес</label>
            <input type="text" class="form-control" id="address" name="address" required>
        </div>
        
        <div class="form-group">
            <label for="metro">Метро</label>
            <input type="text" class="form-control" id="metro" name="metro" required>
        </div>
        
         <div class="form-group">
            <label for="discount">Персональная скидка, если есть</label>
            <input type="number" class="form-control" id="discount" name="discount">
        </div>
        
        <button type="submit" class="btn btn-secondary">Регистрация</button>
    </form>
</div>



<script>
    $('#phone').mask('+7(000)000-00-00', {placeholder: "(111)111-11-11" });
</script>




</body>
</html>