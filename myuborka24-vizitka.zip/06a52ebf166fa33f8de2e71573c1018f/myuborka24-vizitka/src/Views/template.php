<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title><?php echo $title;?></title>
     <link rel="stylesheet" href="css/style.css">
     
     <link rel="stylesheet" href="css/bootstrap.css">
     <link rel="stylesheet" href="css/bootstrap-grid.css">
     
     <link rel="stylesheet" href="css/font-awesome.css">
     <link rel="stylesheet" href="css/normalize.css">
     
     
     <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.bundle.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    
    
     
</head>
<body>
     
     
<div class="desktop-menu">     
<div class="container-fluid">
     <div class="row">   

  <nav class="navbar navbar-dark bg-green">
   

<div class="col">   
<div class="logo">
     <img src="images/gazprom.png" class="logo-image" alt="">
</div> 
</div> 

<div class="col">
<div class="phone"><a href="#" class="telephone">8 812 909 32 23</a></div>
</div>


<div class="col-6">
<div class="clearfix main-menu">
	<ul class="clearfix">
		<li><a href="/">ГЛАВНАЯ</a></li>
		<li><a href="/services">УСЛУГИ</a></li>
		<li><a href="/portfolio">ПОРТФОЛИО</a></li>
		<li><a href="/prices">ЦЕНЫ</a></li>
		<li><a href="testimonial">ОТЗЫВЫ</a></li>
		<li><a href="/contacts">КОНТАКТЫ</a></li>	
	</ul>
	<a href="#" id="pull">Меню</a>
</div>   
</div>

<div class="col">
    

     <p><a href="#" class="zvonok zvonok-button mb-5">Обратный звонок</a></p>
     
     <p><a href="#" id="kabinet" class="zvonok zvonok-button mb-5">Личный кабинет</a></p>   
     
<div class="hide" id="hideBlock">  
<div id="close-form"></div>
     <?php if ($auth):?>
            <ul class="navbar-nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link" href="/account/logout">Выйти</a>
                </li>
            </ul>
        <?php else: ?>
       
            <form method="post" action="/account/auth" class="my-lg-0 formCabinet">
                 
                <div class="mt-40"> 
                <p><input class="input" name="email" class="" type="email" placeholder="e-mail"></p>
                <p><input class="input" name="password" class="" type="password" placeholder="password"></p>
                
                <button class="input" type="submit">Войти</button>
            </form>
            <ul class="">
                <li class="">
                    <div class="input" ><center><a id="reg" href="/account/registration">Регистрация</a></center></div>
                </li>
            </ul>
        <?php  endif;?>
   
   </div>
   
 </div>   
    
  </nav>
</div>
     


</div>
</div>
</div>


<!--------МОБИЛЬНОЕ МЕНЮ!------->



<!--div class="mobile-menu">     
<div class="container-fluid">
     <div class="row">   

  <nav class="navbar navbar-dark bg-green">
   

<div class="col">   
<div class="logo">
     <img src="images/gazprom.png" class="logo-image" alt="">
</div> 
</div> 

<div class="col">
<div class="phone"><a href="#" class="telephone">8 812 909 32 23</a></div>
</div>


<div class="col-6">
<div class="clearfix main-menu">
	<ul class="clearfix">
		<li><a href="/">ГЛАВНАЯ</a></li>
		<li><a href="/services">УСЛУГИ</a></li>
		<li><a href="/portfolio">ПОРТФОЛИО</a></li>
		<li><a href="/prices">ЦЕНЫ</a></li>
		<li><a href="testimonial">ОТЗЫВЫ</a></li>
		<li><a href="/contacts">КОНТАКТЫ</a></li>	
	</ul>
	<a href="#" id="pull">Меню</a>
</div>   
</div>

<div class="col">
    

     <p><a href="#" class="zvonok zvonok-button mb-5">Обратный звонок</a></p>
     
     <p><a href="#" id="kabinet" class="zvonok zvonok-button mb-5">Личный кабинет</a></p>   
     
<div class="hide" id="hideBlock">  
<div id="close-form"></div>
     <?php if ($auth):?>
            <ul class="navbar-nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link" href="/account/logout">Выйти</a>
                </li>
            </ul>
        <?php else: ?>
       
            <form method="post" action="/account/auth" class="my-lg-0 formCabinet">
                 
                <div class="mt-40"> 
                <p><input class="input" name="email" class="" type="email" placeholder="e-mail"></p>
                <p><input class="input" name="password" class="" type="password" placeholder="password"></p>
                
                <button class="input" type="submit">Войти</button>
            </form>
            <ul class="">
                <li class="">
                    <div class="input" ><center><a id="reg" href="/account/registration">Регистрация</a></center></div>
                </li>
            </ul>
        <?php  endif;?>
   
   </div>
   
 </div>   
    
  </nav>
</div>
     


</div>
</div>
</div--!>



<!--------МОБИЛЬНОЕ МЕНЮ--------!>




<!--div class="margin-50 container-fluid">
    <//?php include_once $content;?>
</div!-->

<div id="slider">
            <div class="mask-slider">



                <ul>
                    <li id="first-slide" class="firstanimation">
                    <img src="images/cleaning-slider-active.jpg" alt="главный слайдер сайта" class="slide-main">
                    
                    <div class="text-slider-active"><h1>УТП ИЗ 75 СИМВОЛОВ</h1> </div>
                    </li>
                    <li id="second-slide" class="secondanimation">
                        <img src="images/cleaning-slider1.jpg" alt="слайдер 1" class="">
                        <div class="text-slider-active"><h1>УТП ИЗ 75 СИМВОЛОВ</h1> </div>
                        </li>
                    <li id="third-slide" class="thirdanimation">
                        <img src="images/cleaning-slider2.jpg" alt="слайдер 2" class="">
                        <div class="text-slider-active"><h1>УТП ИЗ 75 СИМВОЛОВ</h1> </div>
                        </li>
                    <li id="fourth-slide" class="fourthanimation">
                        <img src="images/cleaning-slider3.jpg" alt="слайдер 3" class="">
                        <div class="text-slider-active"><h1>УТП ИЗ 75 СИМВОЛОВ</h1> </div>

                        </li>
                        
 
                  
                        
                </ul>

        </div>

         <div class="progress-bar"></div>  <!-- Строка выполнения-->

</div>


<div class="container-fluid">
     <div class="col-sm-12 col-md-12 col lg-12">
     <div class="text-area1">
          <h2>ЗАГОЛОВОК ТЕКСТА</h2>
          
          <p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam, non, ab, voluptates dolores corporis quae voluptatum eaque dolorum sint aperiam magni aliquid commodi recusandae mollitia et! Dolores, nam, modi. Nemo.</span>
          <span>Impedit, accusantium, porro, nisi, corporis at repellendus nostrum voluptates unde ex perferendis vitae ullam reprehenderit provident commodi nam mollitia ab fugit modi harum ipsum atque odio labore fuga totam accusamus!</span>
          <span>Temporibus, odio, accusantium, rem, illo eaque nisi quas tenetur molestiae ex adipisci obcaecati ipsa aperiam quibusdam aliquam earum dolorem eveniet mollitia cumque dolor sequi ullam quae atque. Illum, fugit, reiciendis!</span>
          <span>Dicta, voluptate, eius, ea quibusdam eveniet suscipit atque perspiciatis accusamus eos obcaecati doloribus ullam minima autem reprehenderit rerum alias nam soluta cum quos nihil repellendus laborum ab minus consectetur tempore.</span>
          <span>Voluptas perspiciatis laboriosam quidem labore consectetur maxime voluptatum eius atque totam! Officia, impedit nostrum voluptatem nesciunt consequatur! Harum, dolorem, nostrum id nulla hic quas quia ullam inventore quasi optio maiores.</span></p>
     </div>
     </div>
</div>



<div class="container mt-50">
     <h2 class="text-typping">НАШИ УСЛУГИ</h2>
     <div class="row">
          
          <div class="col-sm center"><img src="images/usluga-tipovaya.jpg" alt="" class="">
          <a href="services/generalnaya" class="service-button">УБОРКА ГЕНЕРАЛЬНАЯ</a>
          </div>
          <div class="col-sm center"><img src="images/usluga-tipovaya.jpg" alt="" class="">
          <a href="#" class="service-button">ПОДРОБНЕЕ</a>
          </div>
          
          <div class="col-sm center"><img src="images/usluga-tipovaya.jpg" alt="" class="">
          <a href="#" class="service-button">ПОДРОБНЕЕ</a>
          </div>
     </div>
</div>



  <div class="container mt-50">
          <div class="podlozhka">

          <div>
              <h2 class="zagolovok">ЗАГОЛОВОК</h2>
          </div>

      <div class="row justify-content-center">

          <div class="col-lg-4 col-md-6 col-sm-12"><div class="float"><img src="images/icons/icon-dish.png" alt=""></div>Ваша выгода 1</div>
        <div class="col-lg-4 col-md-6 col-sm-12"><div class="float"><img src="images/icons/icon-pilesos-dark.png" alt=""></div>Ваша выгода 2</div>
        <div class="col-lg-4 col-md-6 col-sm-12"><div class="float"><img src="images/icons/icon-himiya-dark.png" alt=""></div>Ваша выгода 3</div>

     </div>

       <div class="mt-50"></div>

        <div class="row justify-content-center">

       <div class="col-lg-4 col-md-6 col-sm-12"><div class="float"><img src="images/icons/icon-lamp.png" alt=""></div>Ваша выгода 4</div>
        <div class="col-lg-4 col-md-6 col-sm-12"><div class="float"><img src="images/icons/icon-brush-dark.png" alt=""></div>Ваша выгода 5</div>
        <div class="col-lg-4 col-md-6 col-sm-12"><div class="float"><img src="images/icons/icon-dish.png" alt=""></div>Ваша выгода 6</div>

        </div>


          </div>


         <div class="mt-50"></div>

<h2>ЗАГОЛОВОК ПОРТФОЛИО</h2>

<div class="row">

<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">   

<div class="portfolio shadow"><img src="images/case-uborka.jpg" alt=""></div>

</div> 

<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">  
<div class="portfolio shadow"><img src="images/case-uborka.jpg" alt=""></div>
</div>

<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">  
<div class="portfolio shadow"><img src="images/case-uborka.jpg" alt=""></div>
</div>


<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">  
<div class="portfolio shadow"><img src="images/case-uborka.jpg" alt=""></div>
</div>

<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">  
<div class="portfolio shadow"><img src="images/case-uborka.jpg" alt=""></div>
</div>

<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">  
<div class="portfolio shadow"><img src="images/case-uborka.jpg" alt=""></div>
</div>

</div>


</div>


<div class="container fluid">

<h2 class="mt-50 mb-30">КОНТРОЛЬ НА КАЖДОМ ЭТАПЕ УБОРКИ, ОТ ЗВОНКА ДО ИСПОЛНЕНИЯ</h2>

<div class="row">
       
     <div class="col-lg-3 col-md-6 col-sm-12">
         
<div class="flip-container shadow" ontouchstart="this.classList.toggle('hover');">
<div class="flipper">
<div class="front">
<!-- front content -->ЭТАП №1. ЗАЯВКА С САЙТА
</div> 
<div class="back">
<!-- back content -->

     Вы оставляете заявку на сайте, либо звоните нам. Оператор уточняет все вопросы по уборке, 
     рассчитывает стоимость, примерные сроки. Согласовывает с Вами дату и время уборки.


</div>
</div>
</div> 
          
         
     </div>
     
          
    
     
     <div class="col-lg-3 col-md-6 col-sm-12">
          
<div class="flip-container shadow" ontouchstart="this.classList.toggle('hover');">
<div class="flipper">
<div class="front">
<!-- front content -->ЭТАП №2. ПОДГОТОВКА К УБОРКЕ
</div> 
<div class="back">
<!-- back content -->

     После получения заявки на складе выделяется инвентарь, оборудование и техника. 
     Составляется наряд на работу.


</div>
</div>
</div> 
     </div>
     
     
     <div class="col-lg-3 col-md-6 col-sm-12">
      <div class="flip-container shadow" ontouchstart="this.classList.toggle('hover');">
<div class="flipper">
<div class="front">
<!-- front content -->ЭТАП №3. ПРОЦЕСС УБОРКИ
</div> 
<div class="back">
<!-- back content -->

     Уборка производится в соответствии с чек-листом и техническим заданием.


</div>
</div>
</div>     
     </div>
     
     <div class="col-lg-3 col-md-6 col-sm-12">
<div class="flip-container shadow" ontouchstart="this.classList.toggle('hover');">
<div class="flipper">
<div class="front">
<!-- front content -->ЭТАП №4. СДАЧА РАБОТ И ОПЛАТА
</div> 
<div class="back">
<!-- back content -->

    По завершению всех работ, они сдаются Заказчику, который принимает работы и проверяет и оплачивает.


</div>
</div>
</div>          
     </div>
</div> 

<h2 class="mt-50 mb-30">НАШИ КЛИЕНТЫ</h2>

<div class="row mt-50">
     
     <div class="clients">
          
<div class="logo-clients"><img src="images/lukoil.png" alt=""></div>
<div class="logo-clients"><img src="images/lukoil.png" alt=""></div>
<div class="logo-clients"><img src="images/lukoil.png" alt=""></div>
<div class="logo-clients"><img src="images/lukoil.png" alt=""></div>
<div class="logo-clients"><img src="images/lukoil.png" alt=""></div>
          
     </div>
     
</div>



<div class="row mt-50 mb-30">
     
<div class="col-lg-6 col-md-12 col-sm-12">

<div class="aktsia shadow">
     <h3>ЗАГОЛОВОК АКЦИИ</h3>
     <p>Текст акции</p>
</div>

</div> 


<div class="col-lg-6 col-md-12 col-sm-12">
    <div class="form-data shadow">
         
         <form action="">
              
              <div class="col">
              <label for="name">Ваше имя</label><br>
              <input type="text" name="name" id="name" />
              </div>
              
              <div class="col">
              <label for="phone">Ваш телефон</label><br>
              <input type="text" name="phone" id="phone" />
              </div>
              <br>
              <input type="submit" value="ОТПРАВИТЬ">
              
         </form>
         
    </div>
</div>
     
</div>

<h3>ТАБЫ ВОПРОСЫ ОТВЕТЫ</h3>

  <section>
    <div class="article">
      <p>Короткий текст</p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Aliquam deserunt quam magni quo voluptate recusandae dolor ullam tenetur hic!
        Architecto necessitatibus molestiae, tempore esse officiis alias laborum cum perspiciatis.
      </p>

    </div>

    <div class="article">
      <p>Короткий текст</p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Aliquam deserunt quam magni quo voluptate recusandae dolor ullam tenetur hic!
        Architecto necessitatibus molestiae, tempore esse officiis alias laborum cum perspiciatis.
      </p>

    </div>

    <div class="article">
      <p>Короткий текст</p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Aliquam deserunt quam magni quo voluptate recusandae dolor ullam tenetur hic!
        Architecto necessitatibus molestiae, tempore esse officiis alias laborum cum perspiciatis.
      </p>

    </div>

    <div class="article">
      <p>Короткий текст</p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Aliquam deserunt quam magni quo voluptate recusandae dolor ullam tenetur hic!
        Architecto necessitatibus molestiae, tempore esse officiis alias laborum cum perspiciatis.
      </p>

    </div>

  </section>


<div class="row mt-50">
     




</div>
     
</div>

<!--Конец контейнера container fluid-->    
   </div>   







<footer>
     
    <div class="zagolovok-footer"><h2>ЗАГОЛОВОК ФУТЕРА</h2></div>
    
    <div class="contaner">
         <div class="row">
              <div class="col-md-6 col-sm-12">
                   
                   <div class="footer-menu"><a href="article">СТАТЬИ</a></div>
                   <div class="footer-menu"><a href="info">ИНФОРМАЦИЯ</a></div>
                    
              </div>
              
               <div class="col-md-6 col-sm-12">
                   
                   <div class="footer-menu"><a href="services">УСЛУГИ</a></div>
                    <div class="footer-menu"><a href="success">УСПЕШНАЯ РЕГИСТРАЦИЯ</a></div>
                    <div class="footer-menu"> <p><a href="services/usluga">Генеральная уборка</a></p></div>
              </div>
              
              
         </div>
    </div>
   
    <div></div> 
     
</footer>

<script src="js/main.js"></script> 
    
</body>
</html>