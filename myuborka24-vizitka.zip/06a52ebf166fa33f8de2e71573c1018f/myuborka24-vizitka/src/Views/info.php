<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title><?php echo $title?></title>
</head>
<body>
     
     <div>
          <h1>Информация об оказании услуг, о времени работы компании, о регламенте уборки.</h1>
     </div>
     
</body>
</html>

