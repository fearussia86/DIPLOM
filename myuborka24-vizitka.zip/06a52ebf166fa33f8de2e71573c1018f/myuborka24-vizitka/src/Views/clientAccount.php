<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $title; ?></title>

  <link rel="stylesheet" href="../css/grid.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
  
</head>
<body>
     
  <header>
     
     
     
     
     
     <nav>
          
        
          
          <div class="logo"><a href="/" ></a></div>
          
          <div class="phone-company"><a href="tel:+78122322323">88122322323</a></div>
          
          <ul class="our-menu">
               <li><a href="/">ГЛАВНАЯ</a></li>
               <li><a href="../services">УСЛУГИ</a></li>
               <li><a href="../portfolio">ПОРТФОЛИО</a></li>
               <li><a href="../testimonial">ОТЗЫВЫ</a></li>
               <li><a href="../prices">ЦЕНЫ</a></li>
               
               <li><a href="../contacts">КОНТАКТЫ</a></li>
          </ul>
          
    
      <p><a href="#" class="zvonok zvonok-button ">Обратный звонок</a>
    <a href="#" id="kabinet" class="zvonok zvonok-button ">Личный кабинет</a></p>
     
      
       
     
<div class="hide" id="hideBlock">  
<div id="close-form"></div>
     <?php if ($auth):?>
            <ul class="navbar-nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link" href="/account/logout">Выйти</a>
                </li>
            </ul>
        <?php else: ?>
       
            <form method="post" action="/account/auth" class="my-lg-0 formCabinet">
                 
                <div class="mt-40"> 
                <p><input class="input" name="email" class="" type="email" placeholder="e-mail"></p>
                <p><input class="input" name="password" class="" type="password" placeholder="password"></p>
                
                <button class="input" type="submit">Войти</button>
            </form>
            <ul class="">
                <li class="regSubmit">
                    <div class="" ><center><a id="reg"  href="/account/registration">Регистрация</a></center></div>
                </li>
            </ul>
        <?php  endif;?>
   
   </div>
   
 </div>   
          
          
     </nav>
     

     
</header>   






<main>
     
     <div class="utp">
          
          <div class="text-slider-active text-center mt-5percents mb-5percents"><h1>Заговок личного кабинета, приходит из базы</h1> </div>
          
     </div>
     
     <div class="wrapper">
          
   
               <div class="tabs_nav tabs-nav">
                    
                    <div class="tabs-nav-item is-active"  data-tab-name="tab-1">РАЗДЕЛ ОФОРМЛЕНИЯ ЗАКАЗА</div>
                    <div class="tabs-nav-item"  data-tab-name="tab-2">ИСТОРИЯ ВАШИХ ЗАКАЗОВ</div>
                    <div class="tabs-nav-item"  data-tab-name="tab-3">КОММЕНТАРИИ И ЖАЛОБЫ</div>
                    
                    
               </div>
               
             
<div class="content-tabs">
                    
           <!--Начало формы оформления заказа, данные уходят в БД!-->         
                    
                    <div class="tab tab-1 is-active">
                         
                         <form id="someForm" action="order/create" ectype="multipart/formdata">
                              
        <fieldset>
        <legend>Личные данные клиента</legend>
        <div>
            <label for="login">ФИО</label>
            <input name="login" id="login" type="text">
            
        </div>
        <div class="form-group">
            <label for="phone">Телефон</label>
            <input type="text" class="form-control" id="phone" name="phone" required>
        </div>
        
        <div>
            <label for="email">Ваша эл. почта</label>
            <input name="email" id="email" type="email">
        </div>
        
        
        <div>
            <label for="address">Адрес уборки</label>
            <input name="address" id="address" type="text">
        </div>
        
        <div>
            <label for="metro">Адрес уборки</label>
            <input name="metro" id="metro" type="text">
        </div>
        
        <div>
            <label for="discount">Величина персональной скидки</label>
            <input name="discount" id="discount" type="number">
        </div>
        

    </fieldset>
    
    
    <fieldset>
         <legend>ИНФОРМАЦИЯ ПО ЗАКАЗУ</legend>
         
     <div>
          <label for="dateReceipt">Дата оформления заявки (автоматом устанавливается).</label>
          <input type="date" id="dateReceipt">
     </div> 
     
     <div>
          <label for="operatorReceipt">Оператор, принявший заказ</label>
          <input type="text" id="operatorReceipt" name="operatorReceipt">
     </div>
     
     <div>
          <label for="titleOrder">Заголовок заказа</label>
          <input type="text" id="titleOrder" name="titleOrder">
     </div>
     
     
     <div>
          <label for="descriptionOrder">Описание заказа</label>
          <textarea name="descriptionOrder" id="descriptionOrder" cols="30" rows="7"></textarea>
     </div>
     
     <div>
          <label for="typeCleaning">Выберите Ваш тип уборки</label>
          <select id="typeCleaning" name="typeCleaning">
            
                <option value="generalnaya" selected="">Генеральная</option>
                <option value="posle_remonta" >После ремонта</option>
                <option value="standartnaya">Стандартная</option>
                <option value="reguliarnaya">Регулярная</option>
           
        </select>
     </div>
     
     <div>
          <label for="mudLevel">Уроверь загрязнения</label>
          <select id="mudLevel" name="mudLevel">
            
                <option value="1" selected="">1 балл</option>
                <option value="2" >2 балла</option>
                <option value="3">3 балла</option>
                <option value="4">4 балла</option>
                <option value="5">5 баллов</option>
        </select>
     </div>
     
     <div>
          <label for="footageOrder">Метраж помещения, м2</label>
          <input type="number" name="footageOrder" id="footageOrder">
     </div>
     
     <div>
          <label for="parogenerator">Необходимость в пароочистителе</label>
          <select id="parogenerator" name="parogenerator">
            
                <option value="yes" selected="">Нужен парогенератор</option>
                <option value="no" >Не нужен парогенератор</option>
                
        </select>
     </div>
     
     <div>
          <label for="stremyanka">Взять ли нам стремянку?</label>
          <select id="stremyanka" name="stremyanka">
            
                <option value="yes" selected="">Нужна стремянка</option>
                <option value="no" >Не нужна стремянка</option>
                
        </select>
     </div>
     
     <div>
          <label for="washingVacuumCleaner">Взять ли нам моющий пылесос</label>
          <select id="washingVacuumCleaner" name="washingVacuumCleaner">
            
                <option value="yes" selected="">Нужен моющий пылесос</option>
                <option value="no" >Не нужен моющий пылесос</option>
                
        </select>
     </div>
     
     <div>
          <label for="windowsQuantity">Количество окон к помывке</label>
          <input type="number" id="windowsQuantity" name="windowsQuantity">
     </div>
     
     
     <div>
          <label for="balconyWindows">Сколько окон на балконе надо мыть?</label>
          <input type="number" id="balconyWindows" name="balconyWindows">
     </div>
     
     <div>
          <label for="dryCleaning">Нужна ли химчистка?</label>
          <select id="dryCleaning" name="dryCleaning">
            
                <option value="yes" selected="">Да, нужна химчистка</option>
                <option value="no" >Химчистка не нужна</option>
                
        </select>
     </div>
     
     
     <div>
          <label for="warshingFurniture">Нужно ли мыть мебель в помещении</label>
         <select id="warshingFurniture" name="warshingFurniture">
            
                <option value="yes" selected="">Да</option>
                <option value="no" >Нет</option>
                
        </select>
     </div>
     
     
     <div>
          <label for="workersAmount">Количество работников</label>
          <input type="number" id="workersAmount" name="workersAmount">
     </div>
     
     <div>
          <label for="typePayment">Способ оплаты</label>
          <select id="typePayment" name="typePayment">
            
                <option value="cash" selected="">cash</option>
                <option value="card" >card</option>
                <option value="raschetniy_schet" >raschetniy_schet</option>
                <option value="online_site" >online_site</option>
                
        </select>
     </div>
     
     <div>
          <label for="dateCleaning">Дата и время уборки</label>
          <input type="datetime" id="dateCleaning" name="dateCleaning">
     </div>
     
     <div>
          <label for="commentsOrder">Краткий комментарий к заказу</label>
          <input type="text" id="commentsOrder" name="commentsOrder">
     </div>
     
     <div>
          <label for="discount">Персональная скидка</label>
          <input type="number" id="discount" name="discount">
     </div>
         
         
         
    </fieldset>
    
    <input type="submit" value="ПОЛУЧИТЬ РАСЧЕТ">
                              
                         </form>
                        
                        
                    </div>
                    
          <!--Конец формы оформления заказа, данные уходят в БД!-->           
                    
                    
                    <div class="tab tab-2">
                         Здесь будет подтягиваться история заказов
                    </div>
                    
                    
                    <div class="tab tab-3">
                         Здесь можно будет оставить комментарии или жалобу на работу
                    </div>
                    
</div>               
               
         
          
          
          
     </div>
   
     
     



<h2 class="text-align-center mt-50 mb-30">НАШИ КЛИЕНТЫ</h2>

<section class="clients">
     
     <div class="clients-item">
          <img src="../images/client1.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client2.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client3.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client4.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client1.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client5.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client5.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client5.jpg" alt="">
     </div>
     
     <div class="clients-item">
         <img src="../images/client1.jpg" alt="">
     </div>
     
     <div class="clients-item">
           <img src="../images/client5.jpg" alt="">
     </div>
     

     
</section>


<section class="aktsia">
     
     <div class="zagolovok"><h2 class="text-align-center mt-50 mb-30">ЗАГОЛОВОК АКЦИИ</h2></div>
     
     <div class="aktsia-item">
          <div class="aktsia-text">
               Текст акции, на 250-300 символов.
          </div>
          
     </div>
     
     <div class="aktsia-form">
          <h3>ФОРМА ЗАКАЗА</h3>
          <form action="" id="Form">
               
               <p><input type="text" placeholder="Введите Ваше имя" name="name"></p>
               <p><input type="tel" placeholder="Введите Ваш телефон" name="phone"></p>
               <p><input type="submit" value="ОТПРАВИТЬ"></p>
               
               
          </form>
          
     </div>
     
     
</section>

</main>





<footer>
     
    <div class="footer-block1">
         <h3>Нижнее меню</h3>
         <ul>
             <li><a href="">Пункт меню 1</a></li>
             <li><a href="">Пункт меню 2</a></li>
             <li><a href="">Пункт меню 3</a></li>
             <li><a href="">Пункт меню 4</a></li>
         </ul>
         
    </div>
    <div class="footer-block2">
         <h3>Популярные услуги</h3>
         <ul>
              <li><a href="">Услуга 1</a></li>
              <li><a href="">Услуга 2</a></li>
              <li><a href="">Услуга 3</a></li>
              <li><a href="">Услуга 4</a></li>
         </ul>
         
    </div>
    <div class="footer-block3">
         <h3>Контактная информация</h3>
         <ul>
              <li>Адрес:</li>
              <li>Телефон:</li>
              <li>Время работы:</li>
              <li>Юридическая информация:</li>
         </ul>
         
    </div>
    

     
</footer>
<script>
    $('#phone').mask('+7(000)000-00-00', {placeholder: "(111)111-11-11" });
</script>

<script src="../js/main.js"></script>
</body>
</html>