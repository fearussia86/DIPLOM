let timeRelocate = setTimeout(function(){
  window.location.href = '/';
}, 15 * 1000);

console.log(timeRelocate);


// начать повторы с интервалом 2 сек

let timer = function() {
     console.log('123');
};

let timerId = setInterval(function() {
     
  

     
}, 1000);

console.log(timerId);



